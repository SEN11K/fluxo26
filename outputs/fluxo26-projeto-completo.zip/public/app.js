const fmt = new Intl.NumberFormat('pt-BR');
const pct = v => `${(v * 100).toFixed(1).replace('.', ',')}%`;
let reference, analysis, scenarios = [], currentScenario, municipalityRows = [];

document.querySelectorAll('nav button').forEach(button => button.addEventListener('click', () => {
  document.querySelectorAll('nav button,.view').forEach(x => x.classList.remove('active'));
  button.classList.add('active'); document.getElementById(button.dataset.view).classList.add('active');
}));

async function boot() {
  reference = await fetch('/api/reference').then(r => r.json());
  try { analysis = await fetch('/api/analysis').then(r => r.ok ? r.json() : Promise.reject()); } catch {}
  renderOverview(); renderQuality(); await loadScenarios();
  if (analysis) {renderMunicipal(analysis);renderRegions(analysis);}
}

function renderOverview() {
  const f = reference.first, s = reference.second, id = reference.referenceIdentity;
  const cards = [
    ['Votos adicionais dos finalistas', id.left, '+11,82% sobre os válidos do 1º turno'],
    ['Votos dos eliminados', id.eliminated, '6 candidatos e candidaturas menores'],
    ['Aumento do comparecimento', id.attendanceIncrease, `${pct(id.attendanceIncrease / f.eligible)} dos aptos`],
    ['Resíduo da identidade', id.residual, 'fechamento contábil exato']
  ];
  document.getElementById('metrics').innerHTML = cards.map(([label, value, sub]) => `<div class="metric"><span>${label}</span><strong>${fmt.format(value)}</strong><small>${sub}</small></div>`).join('');
  const parts = [
    ['Eliminados no 1º turno', id.eliminated, '#0a6b58'], ['Comparecimento líquido', id.attendanceIncrease, '#4975d1'],
    ['Redução de brancos', id.blankReduction, '#ee7d4d'], ['Redução de nulos', id.nullReduction, '#bb4c53']
  ];
  document.getElementById('identity-bars').innerHTML = parts.map(([label, value, color]) => `<div class="identity-row"><span>${label}</span><div class="bar"><i style="width:${value / id.left * 100}%;background:${color}"></i></div><strong>${fmt.format(value)}</strong></div>`).join('');
  new Chart(document.getElementById('movementChart'), { type:'bar', data:{ labels:['Comparecimento','Abstenção','Brancos','Nulos','Válidos'], datasets:[{label:'1º turno',data:[f.attendance,f.abstention,f.blankVotes,f.nullVotes,f.validVotes],backgroundColor:'#a9b2b5'},{label:'2º turno',data:[s.attendance,s.abstention,s.blankVotes,s.nullVotes,s.validVotes],backgroundColor:'#0a6b58'}]},options:{responsive:true,plugins:{legend:{position:'bottom'}},scales:{y:{ticks:{callback:v=>`${(v/1e6).toFixed(0)} mi`},grid:{color:'#e4e1da'}},x:{grid:{display:false}}}}});
}

async function loadScenarios() {
  const first = reference.first, second = reference.second;
  const eliminated = Object.entries(first.candidates).filter(([k]) => !['lula','flavio'].includes(k)).reduce((s,[,v])=>s+v,0);
  const groups = { lula:first.candidates.lula, flavio:first.candidates.flavio, eliminated, blankNull:first.blankVotes+first.nullVotes, abstention:first.abstention };
  const targets = { lula:second.candidates.lula, flavio:second.candidates.flavio, blank:second.blankVotes, null:second.nullVotes, abstention:second.abstention };
  const response = await fetch('/api/scenarios',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({groups,targets})}).then(r=>r.json());
  scenarios = response.scenario;
  const select=document.getElementById('scenario-select');
  select.innerHTML=scenarios.filter(s=>s.type==='named').map((s,i)=>`<option value="${i}">${s.label}</option>`).join('');
  select.addEventListener('change',()=>selectScenario(Number(select.value)));
  document.getElementById('apply-scenario').addEventListener('click',recalculate);
  selectScenario(0); renderRanges(response.ranges);
}

function selectScenario(index){ currentScenario=scenarios[index]; const row=currentScenario.probabilities.eliminated; document.getElementById('sliders').innerHTML=Object.entries(row).filter(([k])=>k!=='outOfUniverse').map(([k,v])=>`<div class="slider"><div class="slider-head"><span>${labels[k]}</span><strong id="v-${k}">${pct(v)}</strong></div><input data-destination="${k}" type="range" min="0" max="100" step="1" value="${Math.round(v*100)}"></div>`).join(''); document.querySelectorAll('.slider input').forEach(input=>input.addEventListener('input',()=>document.getElementById(`v-${input.dataset.destination}`).textContent=`${input.value}%`)); renderMatrix(currentScenario); }

async function recalculate(){ const desired={}; document.querySelectorAll('.slider input').forEach(i=>desired[i.dataset.destination]=Number(i.value)); const total=Object.values(desired).reduce((a,b)=>a+b,0)||1; Object.keys(desired).forEach(k=>desired[k]/=total); const prior=structuredClone(currentScenario.probabilities); prior.eliminated=desired; const response=await fetch('/api/scenarios',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({groups:currentScenario.rowTotals,targets:currentScenario.columnTotals,prior})}).then(r=>r.json()); currentScenario=response.scenario; renderMatrix(currentScenario); }

const labels={lula:'Lula',flavio:'Flávio Bolsonaro',eliminated:'Candidatos eliminados',blankNull:'Branco ou nulo',abstention:'Abstenção',blank:'Branco',null:'Nulo',newElectorate:'Novo eleitorado',outOfUniverse:'Fora do universo'};
function renderMatrix(s){ const cols=Object.keys(s.columnTotals), rows=Object.keys(s.rowTotals); document.getElementById('matrix').innerHTML=`<thead><tr><th>Origem</th>${cols.map(c=>`<th>${labels[c]??c}</th>`).join('')}</tr></thead><tbody>${rows.map(r=>`<tr><th>${labels[r]??r}<br><small>${fmt.format(s.rowTotals[r])}</small></th>${cols.map(c=>{const v=s.probabilities[r][c];return `<td class="num"><span class="heat" style="background:rgba(10,107,88,${Math.min(.55,v*.8)})">${pct(v)}</span></td>`}).join('')}</tr>`).join('')}</tbody>`; const badge=document.getElementById('matrix-error'); badge.textContent=`erro máx. ${s.residual.toExponential(1)}`; badge.className='pill success'; }
function renderRanges(ranges){ const entries=Object.entries(ranges).filter(([k])=>k.startsWith('eliminated->')).slice(0,6); document.getElementById('ranges').innerHTML=entries.map(([k,v])=>`<div class="range-card"><small>${labels[k.split('->')[1]]}</small><strong>${pct(v.min)} — ${pct(v.max)}</strong><div class="range-line"><i style="width:${v.width*100}%"></i></div><small>${v.identifiable?'estreito nesta amostra':'amplo / não identificado'}</small></div>`).join(''); }

function renderMunicipal(data){ municipalityRows=data.municipalityDifferences??[]; const c=data.coverage,i=data.municipalStatistics?.identityByUnit; document.getElementById('coverage-copy').textContent=`${fmt.format(c.comparableCount)} unidades comparáveis; ${c.onlyFirst.length} apenas no 1º turno; ${c.onlySecond.length} apenas no 2º.${i?` Identidade exata em ${fmt.format(i.exact)} de ${fmt.format(i.tested)} unidades; soma dos resíduos: ${fmt.format(i.sumResiduals)}.`:''}`; document.getElementById('data-status').textContent='Dados municipais carregados'; document.getElementById('export-municipal').disabled=false; updateMunicipal(); document.getElementById('municipal-search').addEventListener('input',updateMunicipal); document.getElementById('municipal-sort').addEventListener('change',updateMunicipal); }
function updateMunicipal(){ const q=document.getElementById('municipal-search').value.toLowerCase(), sort=document.getElementById('municipal-sort').value; const rows=municipalityRows.filter(r=>`${r.municipalityName} ${r.uf}`.toLowerCase().includes(q)).sort((a,b)=>Math.abs(b[sort])-Math.abs(a[sort])).slice(0,500); document.querySelector('#municipal-table tbody').innerHTML=rows.map(r=>`<tr><td>${r.municipalityName??r.municipalityCode}</td><td>${r.uf}</td>${['attendanceChange','abstentionChange','blankChange','nullChange','validChange'].map(k=>`<td class="num">${r[k]>=0?'+':''}${fmt.format(r[k])}</td>`).join('')}<td class="num"><span class="pill ${r.identityHolds?'success':''}">${r.identityHolds?'exata':`resíduo ${fmt.format(r.identityResidual)}`}</span></td></tr>`).join(''); }

let regionData={};
function renderRegions(data){regionData=data.substateRegions??{};const featured=regionData.custom??[];document.getElementById('region-highlights').innerHTML=featured.map(r=>`<div class="metric"><span>${r.regionName}</span><strong>+${fmt.format(r.finalistIncrease)}</strong><small>${fmt.format(r.municipalityCount)} municípios • Lula +${fmt.format(r.lulaChange)} • Flávio +${fmt.format(r.flavioChange)}</small></div>`).join('');document.getElementById('region-level').addEventListener('change',updateRegions);document.getElementById('region-search').addEventListener('input',updateRegions);updateRegions();}
function updateRegions(){const level=document.getElementById('region-level').value,q=document.getElementById('region-search').value.toLowerCase(),rows=(regionData[level]??[]).filter(r=>`${r.regionName} ${r.uf??''}`.toLowerCase().includes(q)).sort((a,b)=>b.finalistIncrease-a.finalistIncrease);document.querySelector('#region-table tbody').innerHTML=rows.map(r=>`<tr><td>${r.regionName}<br><small>${r.basis??r.regionType}</small></td><td>${r.uf??'—'}</td><td class="num">${fmt.format(r.municipalityCount)}</td><td class="num">${r.lulaChange>=0?'+':''}${fmt.format(r.lulaChange)}</td><td class="num">${r.flavioChange>=0?'+':''}${fmt.format(r.flavioChange)}</td><td class="num">${r.finalistIncrease>=0?'+':''}${fmt.format(r.finalistIncrease)}</td><td class="num">${fmt.format(r.eliminatedVotesFirst)}</td><td class="num">${r.attendanceChange>=0?'+':''}${fmt.format(r.attendanceChange)}</td><td><span class="pill ${r.identityHolds?'success':''}">${r.identityHolds?'exata':fmt.format(r.identityResidual)}</span></td></tr>`).join('');}

function renderQuality(){ document.getElementById('sources').innerHTML=reference.sources.map(s=>`<div class="source"><strong>${s.label}</strong><br><a href="${s.url}" target="_blank">Abrir fonte oficial ↗</a><br><small>gerado na fonte: ${s.generatedAtSource}</small></div>`).join(''); document.getElementById('catalog-warning').textContent=reference.catalogWarning; const q=analysis?.quality; document.getElementById('quality-cards').innerHTML=q?`<span class="kicker">VALIDAÇÃO MUNICIPAL</span><h2>${q.first.errors+q.second.errors} erros encontrados</h2><p>1º turno: ${fmt.format(q.first.rowCount)} linhas • ${q.first.duplicates} duplicadas</p><p>2º turno: ${fmt.format(q.second.rowCount)} linhas • ${q.second.duplicates} duplicadas</p>`:`<span class="kicker">VALIDAÇÃO MUNICIPAL</span><h2>Aguardando CSVs completos</h2><p>O modo nacional de referência está validado. Importe os arquivos municipais para executar duplicatas, ausências, balanço de categorias e cobertura entre turnos.</p>`; }

async function download(format,data,name){const blob=await fetch('/api/export',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({format,data})}).then(r=>r.blob());const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=name;a.click();URL.revokeObjectURL(a.href)}
document.getElementById('export-model').addEventListener('click',()=>download('json',currentScenario,'cenario-transicao.json'));
document.getElementById('export-municipal').addEventListener('click',()=>download('csv',municipalityRows,'diferencas-municipais.csv'));
document.getElementById('export-regions').addEventListener('click',()=>download('csv',[...(regionData.custom??[]),...(regionData.intermediate??[]),...(regionData.immediate??[])],'variacoes-regioes-subestaduais.csv'));
document.getElementById('bayes-run').addEventListener('click',async()=>{const ids=['b-observed','b-mean','b-sd','b-prior','b-shift','b-shift-sd'],box=document.getElementById('bayes-result');if(ids.some(id=>document.getElementById(id).value==='')){box.innerHTML='<strong>Incompleto</strong><span>Preencha todas as premissas; o programa não inventa taxa-base nem mecanismo de fraude.</span>';return;}const v=id=>Number(document.getElementById(id).value);const input={observedMargin:v('b-observed'),predictiveMean:v('b-mean'),predictiveSd:v('b-sd'),priorFraud:v('b-prior')/100,fraudShiftMean:v('b-shift'),fraudShiftSd:v('b-shift-sd')};const response=await fetch('/api/fraud-conditional',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(input)}).then(r=>r.json());if(response.error){box.innerHTML=`<strong>Erro</strong><span>${response.error}</span>`;return;}box.innerHTML=`<strong>${(response.result.posteriorFraud*100).toFixed(2).replace('.',',')}%</strong><span>posterior sob estas premissas • razão de verossimilhança ${response.result.likelihoodRatio.toFixed(3)}</span>`;});
boot();
